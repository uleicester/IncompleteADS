#include <iostream>
#include <vector>
#include <set>
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>

using namespace std;


void rippleAdd(int index, vector<int> & currentInputSequence, int inputs)
{
	if(currentInputSequence.size()>index)
	{
		currentInputSequence[index]=0;
	}
	if(currentInputSequence.size()>index+1)
	{
		int currentIndex = index+1;
		currentInputSequence[currentIndex]++;
		if(currentInputSequence[currentIndex] >= inputs)
		{
			rippleAdd(currentIndex,currentInputSequence,inputs);
		}
	}
	//else{
	//	length++;
	//	currentInputSequence.assign(length,0);
	//}
}
void increment(vector<int> &currentInputSequence, int inputs)
{
	int firstIndex = 0 ;
	currentInputSequence[firstIndex]++;
	if(currentInputSequence[firstIndex] >= inputs)
	{
		rippleAdd(firstIndex,currentInputSequence, inputs);
	}
}

vector<int>retrieveInputSequence(vector<int> &currentInputSequence, int inputs)
{
	int firstIndex = 0;
	if(currentInputSequence[firstIndex]+1 >= inputs)
	{
		increment(currentInputSequence, inputs);
	}
	else
	{
		currentInputSequence[firstIndex]++;
	}
	return currentInputSequence;
}


struct c_unique {
  int current;
  c_unique() {current=-1;}
  int operator()() {return ++current;}
} UniqueNumber;

struct inv
{
	int source, destination, input;
};
struct StatesBlock
{
	int states;
	bool distinguished;
	bool propagated;
	vector<string> sequence;
	int weight;
};

struct Block
{
	vector<int> initialStates;
	vector<int> currentStates;
	vector<int> inputSequence;
	int bId;
	int output;
	bool isALeaf;
};
struct D
{	pair<int,int> pair;
	vector<string> sequence;
	bool separated;
};
struct level
{
	vector<Block> B;
	//int numberOfLevelBlocks;	
};
class IADS
{
public:
	IADS(FSM &f, int id, bool useInvertibleSequencePair,bool useInvertibleSequence);
	~IADS();
	void printIADSs(string fname, FSM &f, float time, bool a, bool b);
	vector<vector<string>> & getSequences();
private:
	int getIndex(int a, int b);
	void generateInput(int number);
	void Start(FSM &f, bool useInvertibleSequencePair,bool useInvertibleSequence);
	void applyInputTree(level &l, int l_c, int in_c, FSM &f);
	void resetBlocks();
	void retrieveDistinguishedPairs(FSM &f, int bound);
	void constructIADSs();
	void compactSequences();
	/*void invertibleStates(FSM &f);*/
	vector<int> retrieveDistinguishedStates(FSM &f, int bound);
	bool stateContainedWithIn(int s, Block &st);
	string getSequenceForState(int s, Block &st);
	vector<int> InvertibleSequenceForAState(FSM &f, vector<int> &ss);
	bool pref(string a, string b);
	bool containedWithIn(pair<int,int> &p, Block &st);
	int invertibleSequenceForAPair(FSM &f);
	int invertibleP(D &b, FSM &f);
	string getSequence(pair<int,int> &p, Block &st);
	vector<int> applyInputToAState(int s,int in_c, FSM &f);
	//vector<int> levelInputs;
	int depth;
	int init_depth;
	int ctr;
	level blocks;
	vector<StatesBlock> SS;
	vector<D> pairs;
	vector<D> separated_pairs;
	vector<vector<string>> I_ADSs;
	vector<inv> Dstates;
	int states;
	int inputs;
	int outputs;
	int separated;
	int invPairs;
	int invStates;
};
vector<vector<string>> & IADS::getSequences()
{
	return I_ADSs;
}
void IADS::printIADSs(string fname, FSM &f, float time,bool a, bool b)
{
	string ID = f.getID();
	ofstream myOfileSeqs;
	ofstream myOfileStats;
	string seqs;
	string stats;
	seqs=fname;
	seqs.append("_sequences_");
	seqs.append(".txt");
	stats=fname;
	stats.append("_stats_");
	stats.append(".txt");
	myOfileSeqs.open(seqs, ios::app);
	myOfileStats.open(stats, ios::app);
	int number_of_sequences = 0;
	int number_of_inputs = 0;
	float number_of_sequences_per_state = 0;
	myOfileSeqs <<"FSM number " << ID.c_str() << " States "<< states << " Inputs "<< inputs << " Outputs "<< outputs;
	if(a&&b)
		myOfileSeqs <<" Invertible sequences"<<endl;
	else if(a&&!b)
		myOfileSeqs <<" Invertible sequence for pairs "<<endl;
	else if(!a&&b)
		myOfileSeqs <<" Invertible sequence for states "<<endl;
	else if(!a&&!b)
		myOfileSeqs <<" No invertible sequences"<<endl;

	myOfileStats <<"FSM number " << ID.c_str() << " States "<< states << " Inputs "<< inputs << " Outputs "<< outputs << " Transitions "<< f.getTransitions() << " Iterations " << ctr;
	if(a&&b)
		myOfileStats <<" Invertible sequences "<<endl;
	else if(a&&!b)
		myOfileStats <<" Invertible sequence for pairs "<<endl;
	else if(!a&&b)
		myOfileStats <<" Invertible sequence for states "<<endl;
	else if(!a&&!b)
		myOfileStats <<" No invertible sequences "<<endl;
	for(int i = 0; i < I_ADSs.size() ; i++)
	{
		
		myOfileSeqs <<"State s"<<i+1<<" {";
		for(int j = 0; j < I_ADSs[i].size() ; j++)
		{
			if(I_ADSs[i][j].size()>0)
			{
				number_of_sequences++;
				number_of_inputs+=I_ADSs[i][j].size();
				myOfileSeqs << I_ADSs[i][j] << " ";
			}
		}
		myOfileSeqs <<" }"<<endl;
	}
	number_of_sequences_per_state = number_of_sequences/(1.0*states);
	myOfileStats <<" time :"<< time <<" msecs. Invertible sequence for states "<< invStates << " Invertible sequence for pairs "<< invPairs<< " total number Of Inputs: " << number_of_inputs<<" total number Of Sequences: "<<number_of_sequences<< " average of number Of Sequences Per State: "<< number_of_sequences_per_state<<  endl;
	myOfileStats.close();
	myOfileSeqs.close();
}
IADS::~IADS(){
	resetBlocks();
	for(int i = 0 ; i < pairs.size() ; i++)
	{
		for(int j = 0 ; j < pairs[i].sequence.size() ; j++)
		{
			pairs[i].sequence[j].clear();
		}
		
	}
	pairs.clear();
	pairs.shrink_to_fit();
	if(I_ADSs.size()>0)
	{
		for(int ias = 0 ; ias < this->states;ias++)
		{
			I_ADSs[ias].clear();
		}
		I_ADSs.clear();
	}
	I_ADSs.shrink_to_fit();
}
IADS::IADS(FSM &f, int id, bool useInvertibleSequencePair,bool useInvertibleSequence)
{
	invPairs=0;
	invStates=0;
	this->depth = 7;
	this->init_depth = 0;
	this->states = f.getStates();
	this->inputs = f.getInputs();
	this->outputs = f.getOutputs();
	for(int ias = 0 ; ias<this->states ; ias++)
	{
		for (int j=ias+1 ; j < this->states ; j++)
		{
			D temp;
			temp.pair.first = ias;
			temp.pair.second = j;
			temp.separated = false;
			temp.sequence.assign(0,"");
			pairs.push_back(temp);
		}
	}
	separated = 0;
	level temp;
	Block firstBlock;
	vector<int> s;
	s.assign(states,-1);
	generate(std::begin(s), std::end(s), UniqueNumber);
	firstBlock.currentStates = s;
	firstBlock.initialStates = s;
	firstBlock.bId = 0;
	firstBlock.output = 0;
	firstBlock.isALeaf = true;
	//level initialLevel;
	blocks.B.push_back(firstBlock);
	I_ADSs.assign(states,vector<string>());
	for(int i = 0 ; i< states ; i++)
	{StatesBlock ts;ts.distinguished = false;ts.states = i;ts.propagated = false; ts.weight = 0;SS.push_back(ts);}
	Start(f,useInvertibleSequencePair,useInvertibleSequence);
	
}
bool IADS::pref(string a, string b)//is a contained in b
{
	if(a.size()>b.size())
		return false;
	for(int i = 0 ; i < a.size() ; i++)
	{
		if(a[i]!=b[i])
			return false;
	}
	return true;
}
void IADS::compactSequences()
{
	/*for(int i = 0 ; i < I_ADSs.size() ; i++)
	{
		vector<string> sequences;
		for(int j = 0 ; j < I_ADSs[i].size() ; j++)
		{
			if(sequences.size()==0 && I_ADSs[i][j]!="")
			{
				sequences.push_back(I_ADSs[i][j]);
			}
			else if(I_ADSs[i][j]!="")
			{
				bool member = false;
				for(int k = 0 ; k < sequences.size() &&!member ; k++)
				{
					if(sequences[k]==I_ADSs[i][j] || pref(sequences[k],I_ADSs[i][j]) || pref(I_ADSs[i][j],sequences[k]) )
						member = true;
				}
				if(!member)
					sequences.push_back(I_ADSs[i][j]);
			}
		}
		I_ADSs[i].clear();
		I_ADSs.shrink_to_fit();
		I_ADSs[i]=sequences;
		sequences.clear();
		sequences.shrink_to_fit();
	}*/
	/*for(int i = 0 ; i < I_ADSs.size() ; i++)
	{
		for(int j = 0 ; j < I_ADSs[i].size() ; j++)
		{
			for(int k= j+1 ; k < I_ADSs[i].size() ; k++)
			{
				if(I_ADSs[i][j]==I_ADSs[i][k])
					I_ADSs[i][k]="";
			if(pref(I_ADSs[i][j],I_ADSs[i][k]))
				I_ADSs[i][j]="";
			if(pref(I_ADSs[i][k],I_ADSs[i][j]))
				I_ADSs[i][k]="";
			}
		}
	}*/
}
void IADS::constructIADSs()
{
	 
	//for(int i = 0 ; i < states ; i++)
	//{
	for(int index = 0; index < pairs.size() ; index++)
	{
		int i = pairs[index].pair.first;
		int j = pairs[index].pair.second;
		if(pairs[index].separated = true)
		{
			for(int k = 0 ; k < pairs[index].sequence.size(); k++)
			{
				string word =pairs[index].sequence[k];

				bool contained = false;
				for(int z = 0 ; z < I_ADSs[pairs[index].pair.first].size() ; z++)
				{
					if( pref(word,I_ADSs[i][z]) )
						contained = true;
					else if( pref(I_ADSs[i][z], word) )
					{
						contained = true;
						I_ADSs[i][z] = word;
					}
				}
				if(!contained)
					I_ADSs[i].push_back(word);
					
					
				contained = false;
				for(int z = 0 ; z < I_ADSs[j].size() ; z++)
				{
					if( pref(word,I_ADSs[j][z]) )
						contained = true;
					else if( pref(I_ADSs[j][z], word) )
					{
						contained = true;
						I_ADSs[j][z] = word;
					}
				}
				if(!contained)
					I_ADSs[j].push_back(word);					
			}
		}			
		//index++;
	}
	//}
}
void IADS::resetBlocks()
{
	for(int i = 0 ; i < blocks.B.size() ; i++)
	{
		blocks.B[i].bId = -1;
		blocks.B[i].currentStates.clear();
		blocks.B[i].initialStates.clear();
		blocks.B[i].output = -1;
		blocks.B[i].inputSequence.clear();
		blocks.B[i].isALeaf = true;
	}
	blocks.B.clear();
	blocks.B.shrink_to_fit();

	level temp;
	Block firstBlock;
	vector<int> s;
	s.assign(states,-1);
	generate(std::begin(s), std::end(s), UniqueNumber);
	firstBlock.currentStates = s;
	firstBlock.initialStates = s;
	firstBlock.bId = 0;
	firstBlock.output = 0;
	firstBlock.isALeaf = true;
	blocks.B.push_back(firstBlock);
}
vector<int> IADS::applyInputToAState(int s,int in_c, FSM &f)
{
	vector<int> r;
	r = f.returnNextStateValue(s,in_c);
	return r;
	
}
void IADS::applyInputTree(level &l, int l_c, int in_c, FSM & f)
{
	
	if(l_c >= l.B.size())//current input tree does not produce enough blocks
		return;
	if(l.B[l_c].currentStates.size()<=1)//current block is singleton
		return;
	if(l.B[l_c].currentStates[0]==-2)//current block is missed transition.
		return;

	vector<int> current_states = l.B[l_c].currentStates;
	
	level thisPartition;
	Block temp;
	temp.bId=-2;
	thisPartition.B.assign(f.getOutputs()+1,temp);
	for(int i=0 ; i < current_states.size() ; i++)
	{
		vector<int> nexStates = applyInputToAState(current_states[i],in_c,f);
		bool noResultGiven = true;
		for(int j = 0 ; j <f.getOutputs() ; j++)
		{
			if(nexStates[j]!=-1)
				noResultGiven = false;
		}
		if(!noResultGiven)//next state is produced
		{
			for(int j = 0 ; j <f.getOutputs() ; j++)
			{
				if(nexStates[j]!=-1)//if not empty
				{					
					thisPartition.B[j].currentStates.push_back(nexStates[j]);
					thisPartition.B[j].initialStates.push_back(l.B[l_c].initialStates[i]);
					thisPartition.B[j].inputSequence = l.B[l_c].inputSequence;
					thisPartition.B[j].inputSequence.push_back(in_c);
				}
			}
		}
		else if(noResultGiven)
		{
			thisPartition.B[outputs].currentStates.push_back(-2);
			thisPartition.B[outputs].initialStates.push_back(l.B[l_c].initialStates[i]);
			thisPartition.B[outputs].isALeaf = true;
		}
	}

	for(int i = 0 ; i < thisPartition.B.size(); i++)
	{
		//i outputvalue.
		if(thisPartition.B[i].currentStates.size()>0)
		{
			l.B[l_c].isALeaf = false;
			thisPartition.B[i].output = i;
			thisPartition.B[i].bId = l.B[l_c].bId * f.getOutputs() + i + 1;
			thisPartition.B[i].isALeaf = true;
			if(thisPartition.B[i].currentStates[0]==-2)
				thisPartition.B[i].bId = -2;
			blocks.B.push_back(thisPartition.B[i]);
		}
	}
}
bool IADS::containedWithIn(pair<int,int> &p, Block &st)
{
	bool f = false;
	bool s = false;	
	bool missingInput = false;
	for(int i = 0 ; i < st.initialStates.size() ; i++ )
	{
		if(p.first == st.initialStates[i])
		{
			if(st.currentStates[i]==-2)
			{
				missingInput = true;
			}
			f = true;		
		}
		if(p.second == st.initialStates[i])
		{
			if(st.currentStates[i]==-2)
			{
				missingInput = true;
			}
			s = true;
		}
	}	
	if((f && s) || missingInput)
		return true;
	else if(!f && !s)
		return false;
	else return false;
}
bool IADS::stateContainedWithIn(int s, Block &st)
{
	bool f = false;
	bool missingInput = false;
	for(int i = 0 ; i < st.initialStates.size() ; i++ )
	{
		if(s == st.initialStates[i] && st.initialStates.size()>1)
		{
			if(st.currentStates[i]==-2)
			{
				missingInput = true;
			}
			f = true;		
		}
		else if(s == st.initialStates[i] && st.initialStates.size()>=1 && st.currentStates[0]==-2)
			missingInput = true;
	}	
	if(f || missingInput)
		return true;
	else return false;
}
string IADS::getSequenceForState(int s, Block &st)
{
	bool f = false;
	for(int i =0 ; i < st.initialStates.size() ; i++)
	{
		string seq;
		if(s == st.initialStates[i] && st.currentStates[i]!=-2)
		{
			for(int j = 0; j < st.inputSequence.size() ; j++)
			{
				//string ch = itoa(st.inputSequence[j],buf,10);
				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
			}
			return seq;
		}
			
	}
	return "";		
}
string IADS::getSequence(pair<int,int> &p, Block &st)
{
	bool f = false;
	bool s = false;
	for(int i =0 ; i < st.initialStates.size() ; i++)
	{
		string seq;
		if(p.first == st.initialStates[i] && st.currentStates[i]!=-2)
		{
			
			//char buf [6];
			for(int j = 0; j < st.inputSequence.size() ; j++)
			{
				//string ch = itoa(st.inputSequence[j],buf,10);
				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
			}
			return seq;
		}
			
		if(p.second == st.initialStates[i])
		{		
			//char buf [6];
			for(int j = 0; j < st.inputSequence.size() ; j++)
			{
				//string ch = itoa(st.inputSequence[j],buf,10);
				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
			}
			return seq;
		}
			
	}
	return "";		
}
void IADS::retrieveDistinguishedPairs(FSM &f, int bound)
{	
	for(int i = 0 ; i <pairs.size() && separated_pairs.size() < pairs.size() ; i++)
	{
		if(!pairs[i].separated)
		{
			bool pairIsSeparated = true;
			for(int j = blocks.B.size()-1; j >= 0 ; j--)
			{
				if(blocks.B[j].isALeaf)
				{
					if(containedWithIn(pairs[i].pair, blocks.B[j]))
					{
						pairIsSeparated = false;// pair is not separated
						break;
					}	
				}
				//else 
				//	break;//all leafs have been processed.
			}
			if(pairIsSeparated)
			{
				
				for(int j = blocks.B.size()-1; j >= 0 ; j--)
				{
					if(blocks.B[j].isALeaf)
					{
						string res = getSequence(pairs[i].pair, blocks.B[j]);
						if(res!="")
						{
							pairs[i].sequence.push_back(res);
							if(!pairs[i].separated)
							{	
								pairs[i].separated = true;	
								/*ofstream file("sep.txt", ios::app);
								file<<pairs[i].pair.first<<" "<<pairs[i].pair.second<<" "<<pairs[i].sequence[0]<<endl;
								file.close();*/
							}
							
						}					
					}
					//else
					//	break;//end of all leaves..
				}
			}
			if(pairs[i].separated)
			{
				separated_pairs.push_back(pairs[i]);				
			}
		}
	}
}
vector<int> IADS::retrieveDistinguishedStates(FSM &f, int bound)
{	
	vector<int>r;
	for(int ias = 0 ; ias <states ; ias++)
	{
		if(!SS[ias].distinguished)
		{
			bool stateIsNotDistinguished = false;
			for(int j = blocks.B.size()-1; j >= 0 ; j--)
			{
				if(blocks.B[j].isALeaf)
				{
					if(stateContainedWithIn(ias, blocks.B[j]))
					{
						stateIsNotDistinguished = true;// pair is not separated
						break;
					}	
				}
				//else 
				//	break;//all leafs have been processed.
			}
			if(!stateIsNotDistinguished)
			{
				r.push_back(ias);		
				for(int j = blocks.B.size()-1; j >= 0 ; j--)
				{
					if(blocks.B[j].isALeaf)
					{
						string res = getSequenceForState(ias, blocks.B[j]);
						if(res!="")
						{
							if(!SS[ias].distinguished)
								SS[ias].distinguished = true;
							SS[ias].sequence.push_back(res);
							SS[ias].states = ias;
							SS[ias].weight+=res.size();
								
						}					
					}
				}
			}
		}
	}
	return r;
}
vector<int> IADS::InvertibleSequenceForAState(FSM &f, vector<int> &ss)
{
	vector<int> res;
	for(int i = 0 ; i < ss.size() ; i++)
	{
		int d_State = ss[i];
		for(int j = 0 ; j < inputs ; j++)
		{
			for (int k = 0 ; k < outputs ; k++)
			{
				int s_state = f.getInv(d_State,j,k);
				if( s_state>= 0 && !SS[s_state].distinguished)
				{
					res.push_back(s_state);
					for(int g = 0 ; g < SS[d_State].sequence.size() ; g++)
					{
						string seq;
						seq.push_back(static_cast<char>(j+97));
						seq.append(SS[ss[i]].sequence[g]);
						SS[s_state].sequence.push_back(seq);
						SS[s_state].weight+=seq.size();
					}			
			
					SS[s_state].distinguished = true;
					invStates++;
					SS[s_state].states = s_state;
			
				}
			}
		}
		
	}
	return res;
}
void IADS::Start(FSM &f, bool useInvertibleSequencePair,bool useInvertibleSequence)
{
	vector<int> inputTree;
	ctr = 0;
	for(int i = init_depth ; separated_pairs.size() < pairs.size() && i<depth; i++)
	{
		if(i==2)
			int gh=0;
		if(separated_pairs.size()<pairs.size() && i>=depth)
		{
			I_ADSs.clear();
			I_ADSs.shrink_to_fit();
			return;
		}
		//int numberOfElements = (pow(inputs,(float)(i)) -1)/((float)(inputs-1));
		int numberOfElements = (pow(outputs,(float)(i+1)) -1)/((float)(outputs-1));
		unsigned long long int numberOfInputSequences = pow((float)inputs,numberOfElements);
		if(numberOfInputSequences>9223372036854775807 || numberOfInputSequences<0)
		{
				numberOfInputSequences = 9223372036854775807;
		}

		inputTree.assign(numberOfElements,0);
		for(int ab = 0 ; ab <numberOfInputSequences && separated_pairs.size() < pairs.size() ; ab++)
		{
			for(int j = 0 ; j < numberOfElements ; j++)
			{
				 if(j < blocks.B.size() && blocks.B[j].bId<inputTree.size())
					applyInputTree(blocks, j, inputTree[blocks.B[j].bId], f);
			}
			
			retrieveDistinguishedPairs(f,numberOfElements);
			
			if(false/*useInvertibleSequence*/)
			{
				vector<int> ss = retrieveDistinguishedStates(f,numberOfElements);;
				vector<int> ss2 = ss;
				do
				{
					ss = InvertibleSequenceForAState(f,ss);
				}
				while(ss.size()>0);
				
				for(int i = 0 ; i < SS.size()&&separated_pairs.size()<pairs.size() ; i++)
				{
					if(SS[i].distinguished)
					{
						for(int j = i+1 ; j < SS.size() &&separated_pairs.size()<pairs.size(); j++)
						{
							if(SS[i].states!=SS[j].states)
							{
								int a = SS[i].states;
								int b = SS[j].states;
									
								if(a>b)
								{
									int temp = a;
									b = a;
									a = temp;
								}
								int index = getIndex(a, b);
								if(SS[j].weight<SS[i].weight)
								pairs[index].sequence = SS[j].sequence;
								else
									pairs[index].sequence = SS[i].sequence;
								pairs[index].separated=true;
								separated_pairs.push_back(pairs[index]);							
							}	
						}
						SS[i].propagated=true;
					}
				}

				/*
				for each pair if a pair is not distinguished
				for each input apply input and get next states
				if next states
				*/
			}
			
			if(false /*useInvertibleSequencePair*/)
			{
				int found = 0;
				do{
					found=invertibleSequenceForAPair(f);
				}while(found>0);
			}
			
			resetBlocks();
			inputTree = retrieveInputSequence(inputTree,inputs);
			ctr++;
		}
	}
	if(separated_pairs.size()==pairs.size())
	{
		constructIADSs();
		f.setCtr(ctr);
	}
}
int IADS::invertibleP(D &b, FSM &f)
{
	int of = b.pair.first;
	int os = b.pair.second;
	if(of!=os && os<of)
	{
		int temp = os;
		os = of;
		of = temp;
	}
	int index1 = getIndex(of,os);
	int sep = 0;
	for(int i = 0 ; i < inputs && !sep && index1>=0 ; i++)
	{
		int first = -1;
		int second = -1;
		for(int o = 0 ; o < outputs ; o++)
		{
			
			int aa = f.getInv(of,i,o);
			int bb = f.getInv(os,i,o);
			if(aa>=0)
				first = aa;
			if(bb>=0)
				second = bb;
		}
		bool merged = false;
			
		if((first==second && first>=0)|| first<0 || second<0)
			merged = true;
		if(!merged)
		{
			if(second<first)
			{
				int temp = second;
				second = first;
				first = temp;
			}
			int index2 = getIndex(first,second);

			if(!pairs[index2].separated)
			{
				sep = 1;
				pairs[index2].separated=true;
				for(int m = 0; m<pairs[index1].sequence.size() ; m++)
				{
					string te;
					te.push_back(static_cast<char>(i+97));
					te.append(pairs[index1].sequence[m]);
					pairs[index2].sequence.push_back(te);
				}
				separated_pairs.push_back(pairs[index2]);//push undistinguished pair.
				invPairs++;
			}
		}
		
	}
	return sep;
}
int IADS::invertibleSequenceForAPair(FSM &f)
{
	int added = 0;
	for(int i = 0 ; i<separated_pairs.size(); i++)
	{
		added += invertibleP(separated_pairs[i],f);
	}
	return added;
}
int IADS::getIndex(int nextState1, int nextState2)
{
	if(nextState1>nextState2)
	{
		int temp = nextState1;
		nextState1 = nextState2;
		nextState2 = temp;
	}
	int index=0;
	for(int k = 0 ; k < nextState1; k++)
	{
		index+=states-k-1;
	}
	index+=nextState2-nextState1-1;
	
	return index;
	
}


//IADS::~IADS(){
//	resetBlocks();
//	for(int i = 0 ; i < pairs.size() ; i++)
//	{
//		for(int j = 0 ; j < pairs[i].sequence.size() ; j++)
//		{
//			pairs[i].sequence[j].clear();
//		}
//		
//	}
//	pairs.clear();
//	pairs.shrink_to_fit();
//	if(I_ADSs.size()>0)
//	{
//		for(int ias = 0 ; ias < this->states;ias++)
//		{
//			I_ADSs[ias].clear();
//		}
//		I_ADSs.clear();
//	}
//	I_ADSs.shrink_to_fit();
//}
//IADS::IADS(FSM &f, int id, bool useInvertibleSequencePair,bool useInvertibleSequence)
//{
//	invPairs=0;
//	invStates=0;
//	this->depth = 9;
//	this->states = f.getStates();
//	this->inputs = f.getInputs();
//	this->outputs = f.getOutputs();
//	for(int ias = 0 ; ias<this->states ; ias++)
//	{
//		for (int j=ias+1 ; j < this->states ; j++)
//		{
//			D temp;
//			temp.pair.first = ias;
//			temp.pair.second = j;
//			temp.separated = false;
//			temp.sequence.assign(0,"");
//			pairs.push_back(temp);
//		}
//	}
//	separated = 0;
//	level temp;
//	Block firstBlock;
//	vector<int> s;
//	s.assign(states,-1);
//	generate(std::begin(s), std::end(s), UniqueNumber);
//	firstBlock.currentStates = s;
//	firstBlock.initialStates = s;
//	firstBlock.bId = 0;
//	firstBlock.output = 0;
//	firstBlock.isALeaf = true;
//	//level initialLevel;
//	blocks.B.push_back(firstBlock);
//	I_ADSs.assign(states,vector<string>());
//	for(int i = 0 ; i< states ; i++)
//	{StatesBlock ts;ts.distinguished = false;ts.states = i;ts.propagated = false;SS.push_back(ts);}
//	Start(f,useInvertibleSequencePair,useInvertibleSequence);
//	
//}
//
//bool IADS::pref(string a, string b)//is a contained in b
//{
//	if(a.size()>b.size())
//		return false;
//	for(int i = 0 ; i < a.size() ; i++)
//	{
//		if(a[i]!=b[i])
//			return false;
//	}
//	return true;
//}
//void IADS::compactSequences()
//{
//	/*for(int i = 0 ; i < I_ADSs.size() ; i++)
//	{
//		vector<string> sequences;
//		for(int j = 0 ; j < I_ADSs[i].size() ; j++)
//		{
//			if(sequences.size()==0 && I_ADSs[i][j]!="")
//			{
//				sequences.push_back(I_ADSs[i][j]);
//			}
//			else if(I_ADSs[i][j]!="")
//			{
//				bool member = false;
//				for(int k = 0 ; k < sequences.size() &&!member ; k++)
//				{
//					if(sequences[k]==I_ADSs[i][j] || pref(sequences[k],I_ADSs[i][j]) || pref(I_ADSs[i][j],sequences[k]) )
//						member = true;
//				}
//				if(!member)
//					sequences.push_back(I_ADSs[i][j]);
//			}
//		}
//		I_ADSs[i].clear();
//		I_ADSs.shrink_to_fit();
//		I_ADSs[i]=sequences;
//		sequences.clear();
//		sequences.shrink_to_fit();
//	}*/
//	/*for(int i = 0 ; i < I_ADSs.size() ; i++)
//	{
//		for(int j = 0 ; j < I_ADSs[i].size() ; j++)
//		{
//			for(int k= j+1 ; k < I_ADSs[i].size() ; k++)
//			{
//				if(I_ADSs[i][j]==I_ADSs[i][k])
//					I_ADSs[i][k]="";
//			if(pref(I_ADSs[i][j],I_ADSs[i][k]))
//				I_ADSs[i][j]="";
//			if(pref(I_ADSs[i][k],I_ADSs[i][j]))
//				I_ADSs[i][k]="";
//			}
//		}
//	}*/
//}
//void IADS::constructIADSs()
//{
//	 
//	//for(int i = 0 ; i < states ; i++)
//	//{
//	for(int index = 0; index < pairs.size() ; index++)
//	{
//		int i = pairs[index].pair.first;
//		int j = pairs[index].pair.second;
//		if(pairs[index].separated = true)
//		{
//			for(int k = 0 ; k < pairs[index].sequence.size(); k++)
//			{
//				string word =pairs[index].sequence[k];
//
//				bool contained = false;
//				for(int z = 0 ; z < I_ADSs[pairs[index].pair.first].size() ; z++)
//				{
//					if( pref(word,I_ADSs[i][z]) )
//						contained = true;
//					else if( pref(I_ADSs[i][z], word) )
//					{
//						contained = true;
//						I_ADSs[i][z] = word;
//					}
//				}
//				if(!contained)
//					I_ADSs[i].push_back(word);
//					
//					
//				contained = false;
//				for(int z = 0 ; z < I_ADSs[j].size() ; z++)
//				{
//					if( pref(word,I_ADSs[j][z]) )
//						contained = true;
//					else if( pref(I_ADSs[j][z], word) )
//					{
//						contained = true;
//						I_ADSs[j][z] = word;
//					}
//				}
//				if(!contained)
//					I_ADSs[j].push_back(word);					
//			}
//		}			
//		//index++;
//	}
//	//}
//}
//void IADS::resetBlocks()
//{
//	for(int i = 0 ; i < blocks.B.size() ; i++)
//	{
//		blocks.B[i].bId = -1;
//		blocks.B[i].currentStates.clear();
//		blocks.B[i].initialStates.clear();
//		blocks.B[i].output = -1;
//		blocks.B[i].inputSequence.clear();
//		blocks.B[i].isALeaf = true;
//	}
//	blocks.B.clear();
//	blocks.B.shrink_to_fit();
//
//	level temp;
//	Block firstBlock;
//	vector<int> s;
//	s.assign(states,-1);
//	generate(std::begin(s), std::end(s), UniqueNumber);
//	firstBlock.currentStates = s;
//	firstBlock.initialStates = s;
//	firstBlock.bId = 0;
//	firstBlock.output = 0;
//	firstBlock.isALeaf = true;
//	blocks.B.push_back(firstBlock);
//}
//vector<int> IADS::applyInputToAState(int s,int in_c, FSM &f)
//{
//	vector<int> r;
//	r = f.returnNextStateValue(s,in_c);
//	return r;
//	
//}
//void IADS::applyInputTree(level &l, int l_c, int in_c, FSM & f)
//{
//	
//	if(l_c >= l.B.size())//current input tree does not produce enough blocks
//		return;
//	if(l.B[l_c].currentStates.size()<=1)//current block is singleton
//		return;
//	if(l.B[l_c].currentStates[0]==-2)//current block is missed transition.
//		return;
//
//	vector<int> current_states = l.B[l_c].currentStates;
//	
//	level thisPartition;
//	Block temp;
//	temp.bId=-2;
//	thisPartition.B.assign(f.getOutputs()+1,temp);
//	for(int i=0 ; i < current_states.size() ; i++)
//	{
//		vector<int> nexStates = applyInputToAState(current_states[i],in_c,f);
//		bool noResultGiven = true;
//		for(int j = 0 ; j <f.getOutputs() ; j++)
//		{
//			if(nexStates[j]!=-1)
//				noResultGiven = false;
//		}
//		if(!noResultGiven)//next state is produced
//		{
//			for(int j = 0 ; j <f.getOutputs() ; j++)
//			{
//				if(nexStates[j]!=-1)//if not empty
//				{					
//					thisPartition.B[j].currentStates.push_back(nexStates[j]);
//					thisPartition.B[j].initialStates.push_back(l.B[l_c].initialStates[i]);
//					thisPartition.B[j].inputSequence = l.B[l_c].inputSequence;
//					thisPartition.B[j].inputSequence.push_back(in_c);
//				}
//			}
//		}
//		else if(noResultGiven)
//		{
//			thisPartition.B[outputs].currentStates.push_back(-2);
//			thisPartition.B[outputs].initialStates.push_back(l.B[l_c].initialStates[i]);
//			thisPartition.B[outputs].isALeaf = true;
//		}
//	}
//
//	for(int i = 0 ; i < thisPartition.B.size(); i++)
//	{
//		//i outputvalue.
//		if(thisPartition.B[i].currentStates.size()>0)
//		{
//			l.B[l_c].isALeaf = false;
//			thisPartition.B[i].output = i;
//			thisPartition.B[i].bId = l.B[l_c].bId * f.getOutputs() + i + 1;
//			thisPartition.B[i].isALeaf = true;
//			if(thisPartition.B[i].currentStates[0]==-2)
//				thisPartition.B[i].bId = -2;
//			blocks.B.push_back(thisPartition.B[i]);
//		}
//	}
//}
//bool IADS::containedWithIn(pair<int,int> &p, Block &st)
//{
//	bool f = false;
//	bool s = false;	
//	bool missingInput = false;
//	for(int i = 0 ; i < st.initialStates.size() ; i++ )
//	{
//		if(p.first == st.initialStates[i])
//		{
//			if(st.currentStates[i]==-2)
//			{
//				missingInput = true;
//			}
//			f = true;		
//		}
//		if(p.second == st.initialStates[i])
//		{
//			if(st.currentStates[i]==-2)
//			{
//				missingInput = true;
//			}
//			s = true;
//		}
//	}	
//	if((f && s) || missingInput)
//		return true;
//	else if(!f && !s)
//		return false;
//	else return false;
//}
//bool IADS::stateContainedWithIn(int s, Block &st)
//{
//	bool f = false;
//	bool missingInput = false;
//	for(int i = 0 ; i < st.initialStates.size() ; i++ )
//	{
//		if(s == st.initialStates[i] && st.initialStates.size()>=1)
//		{
//			if(st.currentStates[i]==-2)
//			{
//				missingInput = true;
//			}
//			f = true;		
//		}
//	}	
//	if(f || missingInput)
//		return true;
//	else return false;
//}
//string IADS::getSequenceForState(int s, Block &st)
//{
//	bool f = false;
//	for(int i =0 ; i < st.initialStates.size() ; i++)
//	{
//		string seq;
//		if(s == st.initialStates[i] && st.currentStates[i]!=-2)
//		{
//			for(int j = 0; j < st.inputSequence.size() ; j++)
//			{
//				//string ch = itoa(st.inputSequence[j],buf,10);
//				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
//			}
//			return seq;
//		}
//			
//	}
//	return "";		
//}
//string IADS::getSequence(pair<int,int> &p, Block &st)
//{
//	bool f = false;
//	bool s = false;
//	for(int i =0 ; i < st.initialStates.size() ; i++)
//	{
//		string seq;
//		if(p.first == st.initialStates[i] && st.currentStates[i]!=-2)
//		{
//			
//			//char buf [6];
//			for(int j = 0; j < st.inputSequence.size() ; j++)
//			{
//				//string ch = itoa(st.inputSequence[j],buf,10);
//				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
//			}
//			return seq;
//		}
//			
//		if(p.second == st.initialStates[i])
//		{		
//			//char buf [6];
//			for(int j = 0; j < st.inputSequence.size() ; j++)
//			{
//				//string ch = itoa(st.inputSequence[j],buf,10);
//				seq.push_back(static_cast<char>(st.inputSequence[j]+97));
//			}
//			return seq;
//		}
//			
//	}
//	return "";		
//}
//void IADS::retrieveDistinguishedPairs(FSM &f, int bound)
//{	
//	for(int i = 0 ; i <pairs.size() && separated_pairs.size() < pairs.size() ; i++)
//	{
//		if(!pairs[i].separated)
//		{
//			bool pairIsSeparated = true;
//			for(int j = blocks.B.size()-1; j >= 0 ; j--)
//			{
//				if(blocks.B[j].isALeaf)
//				{
//					if(containedWithIn(pairs[i].pair, blocks.B[j]))
//					{
//						pairIsSeparated = false;// pair is not separated
//						break;
//					}	
//				}
//				//else 
//				//	break;//all leafs have been processed.
//			}
//			if(pairIsSeparated)
//			{
//				for(int j = blocks.B.size()-1; j >= 0 ; j--)
//				{
//					if(blocks.B[j].isALeaf)
//					{
//						string res = getSequence(pairs[i].pair, blocks.B[j]);
//						if(res!="")
//						{
//							pairs[i].sequence.push_back(res);
//							if(!pairs[i].separated)
//							{	
//								pairs[i].separated = true;								
//							}
//							
//						}					
//					}
//					//else
//					//	break;//end of all leaves..
//				}
//			}
//			if(pairs[i].separated)
//			{
//				separated_pairs.push_back(pairs[i]);
//				
//			}
//		}
//	}
//}
//vector<int> IADS::retrieveDistinguishedStates(FSM &f, int bound)
//{	
//	vector<int>r;
//	for(int ias = 0 ; ias <states ; ias++)
//	{
//		if(!SS[ias].distinguished)
//		{
//			bool stateIsNotDistinguished = false;
//			for(int j = blocks.B.size()-1; j >= 0 ; j--)
//			{
//				if(blocks.B[j].isALeaf)
//				{
//					if(stateContainedWithIn(ias, blocks.B[j]))
//					{
//						stateIsNotDistinguished = true;// pair is not separated
//						break;
//					}	
//				}
//				//else 
//				//	break;//all leafs have been processed.
//			}
//			if(!stateIsNotDistinguished)
//			{
//				r.push_back(ias);		
//				for(int j = blocks.B.size()-1; j >= 0 ; j--)
//				{
//					if(blocks.B[j].isALeaf)
//					{
//						string res = getSequenceForState(ias, blocks.B[j]);
//						if(res!="")
//						{
//							if(!SS[ias].distinguished)
//								SS[ias].distinguished = true;
//							SS[ias].sequence.push_back(res);
//							SS[ias].states = ias;
//								
//						}					
//					}
//				}
//			}
//		}
//	}
//	return r;
//}
//vector<int> IADS::InvertibleSequenceForAState(FSM &f, vector<int> &ss)
//{
//	vector<int> res;
//	for(int i = 0 ; i < ss.size() ; i++)
//	{
//		int d_State = ss[i];
//		for(int j = 0 ; j < inputs ; j++)
//		{
//			for (int k = 0 ; k < outputs ; k++)
//			{
//				int s_state = f.getInv(d_State,j,k);
//				if( s_state>= 0 && !SS[s_state].distinguished)
//				{
//					res.push_back(s_state);
//					for(int g = 0 ; g < SS[ss[i]].sequence.size() ; g++)
//					{
//						string seq;
//						seq.push_back(static_cast<char>(j+97));
//						seq.append(SS[ss[i]].sequence[g]);
//						SS[s_state].sequence.push_back(seq);
//					}			
//			
//					SS[s_state].distinguished = true;
//					invStates++;
//					SS[s_state].states = s_state;
//			
//				}
//			}
//		}
//		
//	}
//	return res;
//}
//void IADS::Start(FSM &f, bool useInvertibleSequencePair,bool useInvertibleSequence)
//{
//	vector<int> inputTree;
//	for(int i = 0 ; i < depth && separated_pairs.size() < pairs.size(); i++)
//	{
//		
//		int numberOfElements = (pow(inputs,(float)(i+1)) -1)/((float)(inputs-1));
//		int numberOfInputSequences = pow((float)inputs,numberOfElements);
//		inputTree.assign(numberOfElements,0);
//		for(int ab = 0 ; ab <numberOfInputSequences && separated_pairs.size() < pairs.size() ; ab++)
//		{
//			for(int j = 0 ; j < numberOfElements ; j++)
//			{
//				if(j < blocks.B.size() && blocks.B[j].bId<inputTree.size())
//					applyInputTree(blocks, j, inputTree[blocks.B[j].bId], f);
//			}
//			if(useInvertibleSequence){
//				vector<int> ss = retrieveDistinguishedStates(f,numberOfElements);;
//				do{
//				ss = InvertibleSequenceForAState(f,ss);
//				}while(ss.size()>0);
//				for(int i = 0 ; i < SS.size()&&separated_pairs.size()<pairs.size() ; i++)
//				{
//					if( SS[i].states>=0 ){
//					if(!SS[i].propagated && SS[i].distinguished)
//					{
//						for(int j = 0 ; j < SS.size() &&separated_pairs.size()<pairs.size(); j++)
//						{
//							if(SS[i].states!=SS[j].states && !SS[j].propagated  &&SS[j].states>=0)
//							{
//								int index = getIndex(SS[i].states, SS[j].states);
//								pairs[index].sequence = SS[i].sequence;
//								pairs[index].separated=true;
//								separated_pairs.push_back(pairs[index]);							
//							}	
//						}
//						SS[i].propagated=true;
//					}
//					}
//				}
//				/*
//				for each pair if a pair is not distinguished
//				for each input apply input and get next states
//				if next states
//				*/
//			}
//			if(useInvertibleSequencePair)
//			{
//				bool found = false;
//			
//				do{
//					found=invertibleSequenceForAPair(f);
//				}while(found);
//			}
//			retrieveDistinguishedPairs(f,numberOfElements);
//			resetBlocks();
//			inputTree = retrieveInputSequence(inputTree,inputs);
//			//if(inputTree.size()>3 && inputTree[inputTree.size()-1]==1 && f.getID()=="27")
//			//	int asd = 0;
//		}
//	}
//
//	constructIADSs();
////	compactSequences();
//}
//bool IADS::invertibleP(D &b, FSM &f)
//{
//	int of = b.pair.first;
//	int os = b.pair.second;
//	if(of!=os && os<of)
//	{
//		int temp = os;
//		os = of;
//		of = temp;
//	}
//	int index1 = getIndex(of,os);
//	bool sep = false;
//	for(int i = 0 ; i < inputs && !sep && index1>=0 ; i++)
//	{
//		int first = -1;
//		int second = -1;
//		for(int o = 0 ; o < outputs ; o++)
//		{
//			
//			int aa = f.getInv(of,i,o);
//			int bb = f.getInv(os,i,o);
//			if(aa>=0)
//				first = aa;
//			if(bb>0)
//				second = bb;
//		}
//		bool merged = false;
//			
//		if((first==second && first>=0)|| first<0 || second<0)
//			merged = true;
//		if(!merged)
//		{
//			if(second<first)
//			{
//				int temp = second;
//				second = first;
//				first = temp;
//			}
//			int index2 = getIndex(first,second);
//
//			if(!pairs[index2].separated)
//			{
//				sep = true;
//				pairs[index2].separated=true;
//				for(int m = 0; m<pairs[index1].sequence.size() ; m++)
//				{
//					string te;
//					te.push_back(static_cast<char>(i+97));
//					te.append(pairs[index1].sequence[m]);
//					pairs[index2].sequence.push_back(te);
//				}
//				separated_pairs.push_back(pairs[index2]);
//				invPairs++;
//			}
//		}
//		
//	}
//	return sep;
//}
//bool IADS::invertibleSequenceForAPair(FSM &f)
//{
//	bool added = false;
//	for(int i = 0 ; i<separated_pairs.size(); i++)
//	{
//		added = invertibleP(separated_pairs[i],f);
//	}
//	return added;
//}
//int IADS::getIndex(int nextState1, int nextState2)
//{
//	if(nextState1>nextState2)
//	{
//		int temp = nextState1;
//		nextState1 = nextState2;
//		nextState2 = temp;
//	}
//	int index=0;
//	for(int k = 0 ; k < nextState1; k++)
//	{
//		index+=states-k-1;
//	}
//	index+=nextState2-nextState1-1;
//	
//	return index;
//	
//}