#include <iostream>
#include <fstream>
#include <chrono>
#include "P.h"

using namespace std;
int main()
{
	ReadFSMs reader("fsm.txt");
	
	for(int i = 0 ; i< 1/*reader.FSMlist.size()*/ ; i++)
	{
		auto start_time = std::chrono::high_resolution_clock::now();
		P petrenko(reader.FSMlist[i]);
		auto end_time = std::chrono::high_resolution_clock::now();
		auto time = end_time - start_time;
		float t = time/std::chrono::milliseconds(1);
		petrenko.printWset("out.txt",i,t);
		petrenko.~P();
		
	}
	return 0;
}
