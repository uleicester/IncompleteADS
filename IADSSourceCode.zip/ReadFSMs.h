#include <iostream>
#include <vector>
#include <set>
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>
#include "FSM.h"
#include "IADS.h"
#include "P.h"



using namespace std;


class ReadFSMs
{
public: 
	ReadFSMs(string fileName);
	vector<FSM> FSMlist;
private:
	void Start();
	void End();
	bool readAnFSM();
	ifstream inputFile;
};

ReadFSMs::ReadFSMs(string fileName)
{
	inputFile.open(fileName.c_str());
	if(!inputFile.is_open()){
		cout<<"File couldn't opened.Please check the file's name!!"<<endl;
		inputFile.close();
	}
	Start();
}
void ReadFSMs::Start()
{
	//int counter = -1;
	bool run = true;
	while(run)
	{		
		//counter = counter + 1;
		run = readAnFSM();
	}
	//cout<<counter<<" FSM(s) read"<<endl;
	End();
}
void ReadFSMs::End()
{
	//cout<<"All FSMs are stored"<<endl;
	inputFile.close();
}
bool ReadFSMs::readAnFSM()
{
	string number;
	int s, tr, inf ,ouf, d;
	inputFile >> number >> s >> inf >> ouf >> tr >> d;
	if(inputFile.eof())
        return false;
 
	
	FSM f(number, s,tr,inf,ouf,d);
	
 	int counter = 0;
	int so,de,in,ou;
	char c;
	while(counter<tr)
	{
		inputFile >> so >> de >> c >> ou;
		if (so==0)
			cout<<"as"<<endl;
		in = int(c)-97;
		//in = int(c)-34;
		so = so-1;
		de = de-1;
		f.setTransition(so,in,ou,de);
		counter++;
	}
	int number_of_string;
	//inputFile >> number_of_string;
	counter = 0;
	string temp;
	/*while(counter<number_of_string)
	{
		inputFile >> temp ;
		f.addSequence(temp);
		counter++;
	}*/
	f.setDeterministicTransition();
	FSMlist.push_back(f);
	f.~FSM();
}