#include <iostream>
#include <fstream>
#include <chrono>
#include "StateIdentifiers.h"

using namespace std;
int main()
{
	//for(int inputs = 4 ; inputs<=20 ; inputs=inputs+2)
	{	
		//for(int states = 10 ; states <= 300 ; states = states+10)
		{
			//string fileName = "fsm_";
			//fileName.append(to_string(states));
			//fileName.push_back('_');
			//fileName.append(to_string(inputs));
			//fileName.append(".txt");
	//		ReadFSMs reader(fileName);
	//		ReadFSMs reader("fsm.txt");
			ReadFSMs reader("benchmark.txt");
			for(int i = 0 ; i< reader.FSMlist.size() ; i++)
			{
				SI si(reader.FSMlist[i]);
				auto start_P_time = std::chrono::high_resolution_clock::now();
				si.Petrenko(reader.FSMlist[i]);
				auto end_P_time = std::chrono::high_resolution_clock::now();
				auto time_P = end_P_time - start_P_time;
				float t_P = time_P/std::chrono::milliseconds(1);
				si.printTestSuite("btsR", reader.FSMlist[i], t_P, 0, 0,0);
				si.END();
						
				for(int j = 0 ; j<=1; j++)
				{
					for(int k = 0 ; k<=1; k++)
					{
						auto start_I_time = std::chrono::high_resolution_clock::now();
						si.Uraz(reader.FSMlist[i],i, 1, 1);
						auto end_I_time = std::chrono::high_resolution_clock::now();
						auto time_I = end_I_time - start_I_time;
						float t_I = time_I/std::chrono::milliseconds(1);
						si.printTestSuite("btsR",reader.FSMlist[i],t_I,j,k,1);
						si.END();
					}			
				}
				si.~SI();
			}
			
			//fileName.clear();
			//fileName.shrink_to_fit();
		}
	}
	
	return 0;
}