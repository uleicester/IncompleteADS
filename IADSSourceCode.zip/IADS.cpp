#include <iostream>
#include <fstream>
#include <chrono>
#include "IADS.h"


using namespace std;
int main()
{
	ReadFSMs reader("fsm.txt");
	auto start_time = std::chrono::high_resolution_clock::now();
	IADS iads(reader.FSMlist[0], 1, 0, 0);
	auto end_time = std::chrono::high_resolution_clock::now();
	auto time = end_time - start_time;
	float t = time/std::chrono::milliseconds(1);
	iads.printIADSs("out",reader.FSMlist[0],t,0,0);
	iads.~IADS();

	for(int inputs = 2 ; inputs<20 ; inputs++)
	{	
		for(int states = 10 ; states < 1000 ; states = states+10)
		{
			string fileName = "fsm_";
			fileName.append(to_string(states));
			fileName.push_back('_');
			fileName.append(to_string(inputs));
			fileName.append(".txt");
			ReadFSMs reader(fileName);
	
			for(int i = 0 ; i< reader.FSMlist.size() ; i++)
			{
				for(int j = 0 ; j<= 1; j++)
				{
					for(int k = 0 ; k<= 1; k++)
					{
						//cout<<reader.FSMlist[i].getID()<< " is being processed at index "<<i<<endl;
						auto start_time = std::chrono::high_resolution_clock::now();
						IADS iads(reader.FSMlist[i], i, j, k);
						auto end_time = std::chrono::high_resolution_clock::now();
						auto time = end_time - start_time;
						float t = time/std::chrono::milliseconds(1);
						iads.printIADSs("out",reader.FSMlist[i],t,j,k);
						iads.~IADS();
					}			
				}		
			}
			fileName.clear();
			fileName.shrink_to_fit();
		}
	}
	
	return 0;
}