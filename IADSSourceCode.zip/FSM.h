#include <iostream>
#include <vector>
#include <set>
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>


using namespace std;
struct inv_st
{
	int input,output,source;
};
class FSM{

	public:
		FSM(string n, int s, int t, int i, int o, int d);
		void setTransition(int so, int in, int ou, int de);
		void addSequence(string s);
		string getID();
		~FSM();
		int getInputs();
		int getDepth();
		int getOutputs();
		int getStates();
		int getTransitions();
		vector<int> returnOutputValues(int s, int i);
		vector<int> returnNextStateValue(int s, int i);
		int getNumberOfSequences();
		void setDeterministicTransition();
		vector<int> getInputSequence(int i);
		int getInv(int de, int in, int ou);
		void setCtr(int c);
		int getCtr();
	private:
		vector<vector<int>> inputs_to_be_applied;
		vector< vector < vector <int >>> transitions;
		vector< vector < vector <int >>> inv_transitions;
		int ctr;
		int number_of_states;
		int number_of_transitions;
		int number_of_inputs;
		int number_of_outputs;
		int depth;
		string id;
		
};
string FSM::getID()
{
	return this->id;
}
vector<int> FSM::getInputSequence(int i)
{
	if(i < inputs_to_be_applied.size())
		return this->inputs_to_be_applied[i];
	else 
		return vector<int>();
}
void FSM::addSequence(string t)
{
	vector<int> num; 
	for(int i = 0 ; i < t.size() ; i++)
	{
		num.push_back(t[i]-97);
	}
	inputs_to_be_applied.push_back(num);
}
int FSM::getNumberOfSequences()
{
	return this->inputs_to_be_applied.size();
}
int FSM::getCtr()
{
	return this->ctr;
}
void FSM::setCtr(int c)
{
	this->ctr = c;
}
int FSM::getInv(int de, int in, int ou)
{
	return this->inv_transitions[de][in][ou];
}
void FSM::setTransition(int so, int in, int ou, int de)
{	
	
	transitions[so][in][ou]=de;
	if(inv_transitions[de][in][ou] !=-1)
		inv_transitions[de][in][ou]=-2;
	else
	{
		inv_transitions[de][in][ou]=so;
	}
}
void FSM::setDeterministicTransition()
{
	for(int i = 0 ; i < transitions.size() ; i++)
	{
		for(int j = 0 ; j < transitions[i].size() ; j++)
		{
			int ctr = 0;
			int ctr2 = 0;
			int tstate = i;
			int inputToBeErased = -1;
			bool notdefined = false;
			for(int k = 0 ; k < transitions[i][j].size() ; k++)
			{
				if(transitions[i][j][k]>=0)
				{
					ctr++;
					inputToBeErased = j;
				}
				if(transitions[i][j][k]<0)
				{
					ctr2++;
				}
			}
			if(ctr2==number_of_outputs)
			{
				notdefined = true;
				inputToBeErased = j;
			}
			if(ctr>1 && !notdefined)
			{
				for(int k = 0 ; k < inv_transitions.size() ; k++)
				{
					//for(int l = 0 ; l < inv_transitions[k].size() ; l++)
					{
						for(int m = 0 ; m < inv_transitions[k][inputToBeErased].size() ; m++)
						{
							if(inv_transitions[k][inputToBeErased][m]== tstate)
							{
								inv_transitions[k][inputToBeErased][m]=-2;
							}
								
						}
					}
				}
			}
			else if (notdefined)
			{
				for(int k = 0 ; k < inv_transitions.size() ; k++)
				{
					for(int l = 0 ; l < inv_transitions[k][inputToBeErased].size() ; l++)
					{
						inv_transitions[k][inputToBeErased][l]=-2;
					}

				}

			}
		}	
	}
}
FSM::FSM(string n, int s, int t, int i, int o, int d)
{
		number_of_states = s;
		number_of_transitions = t;
		number_of_inputs = i;
		number_of_outputs = o;
		depth = d;
		id = n;
		ctr = 0;
		vector<int> ous;
		ous.assign(number_of_outputs,-1);
		transitions.assign(s,vector<vector<int>>(number_of_inputs,ous));
		inv_transitions.assign(s,vector<vector<int>>(number_of_inputs,ous));
}
FSM::~FSM()
{
	ctr= 0;
	for(int i = 0 ; i < transitions.size() ; i++){
		transitions[i].clear();
		inv_transitions[i].clear();
	}
	inv_transitions.clear();
	transitions.clear();
	number_of_inputs = 0 ; 
	number_of_outputs = 0 ;
	number_of_states = 0 ;
	number_of_transitions = 0;
}
int FSM::getInputs()
{
	return this->number_of_inputs;
}
int FSM::getDepth()
{
	return this->depth;
}
int FSM::getTransitions()
{
	return this->number_of_transitions;
}
int FSM::getOutputs()
{
	return this->number_of_outputs;
}
int FSM::getStates()
{
	return this->number_of_states;
}
vector<int> FSM::returnOutputValues(int s, int i)
{
	vector<int> re;
	re.assign(getOutputs(),-1);
	for(int j = 0 ; j < number_of_outputs ; j++)
	{
		if(transitions[s][i][j]!=-1)
			re[j]=j;
		else 
			re[j]=-1;
	}
	return re;
}
vector<int> FSM::returnNextStateValue(int s, int i)
{
	vector<int> re;
	re.assign(getOutputs(),-1);
	for(int j = 0 ; j < number_of_outputs ; j++)
	{
		if(transitions[s][i][j]!=-1)
			re[j]=transitions[s][i][j];
		else 
			re[j]=-1;
	}
	return re;
}