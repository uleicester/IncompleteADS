#include <iostream>
#include <vector>
#include <set>
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <fstream>

using namespace std;

//struct c_unique {
//  int current;
//  c_unique() {current=-1;}
//  int operator()() {return ++current;}
//} UniqueNumber;

struct pairsBlock
{
	pair<int,int> initial;
	pair<int,int> current;
};
struct levelPairsBlocks
{
	vector<pairsBlock> l;
	string inputSequence;
};
//struct D
//{
//	pair<int,int> pair;
//	vector<string> sequence;
//	bool separated;
//};

class P{
public:
	P(FSM &f);
	~P();
	void printWset(string fname, int i, float t);
	vector<vector<string>> & getSequences();
private:
	vector<vector<string>> tempW;
	int states; 
	int inputs; 
	int outputs;
	int length;
	vector<D> pSet;
	vector<levelPairsBlocks> allLevels;
	vector<int> currentInputSequence;
	void Start(FSM &f);
	bool areAllSingletons(levelPairsBlocks & res);
	vector<int> getInputSequence();
	
	void compactWset();
	bool pref(string a, string b);
	int applyInput(levelPairsBlocks & LPB, int input, FSM &f);
	levelPairsBlocks applyInputToAPair(pairsBlock & p, int input, FSM &f);
	void increment(vector<int> &myArray);
	vector<int> retreiveFirstInput();
	void rippleAdd(int index, vector<int> &myArray);
	vector<int> retrieveInputSequence();
};
P::P(FSM &f)
{
	
	this->states = f.getStates();
	this->inputs = f.getInputs();
	this->outputs = f.getOutputs();
	tempW.assign(states,vector<string>());
	for(int i = 0 ; i<states ; i++)
	{
		for (int j = i+1 ; j < states ; j++)
		{
			D temp;
			temp.pair.first = i;
			temp.pair.second = j;
			temp.separated = false;
			pSet.push_back(temp);
		}
	}
	length = 1;
	Start(f);
	compactWset();
}
vector<vector<string>> & P::getSequences()
{
	return tempW;
}
P::~P()
{
	for(int i = 0 ; i<pSet.size() ; i++)
	{
		pSet[i].sequence.clear();
		pSet[i].sequence.shrink_to_fit();
		
	}
	tempW.clear();
	tempW.shrink_to_fit();
	for(int i = 0 ; i<allLevels.size() ; i++)
	{
		allLevels[i].inputSequence.clear();
		allLevels[i].l.clear();
		allLevels[i].l.shrink_to_fit();
	}
	allLevels.clear();
	allLevels.shrink_to_fit();

	this->states = -1;
	this->inputs = -1;
	this->outputs = -1;
}
void P::printWset(string fname, int i, float t)
{
	ofstream myOfile;
	myOfile.open(fname, ios::app);
	int ni = 0;
	int ns = 0; 
	double ps = 0;
	myOfile <<"FSM number" << i+1 << " ";
	for(int j = 0; j < tempW.size() ; j++)
	{
		myOfile <<"State s" << j+1 << " { ";
		for(int k = 0; k < tempW[j].size() ; k++)
		{
			ns++;
			ni += tempW[j][k].size();
			myOfile << tempW[j][k] << " ";
		}
		myOfile << " } "<<endl;
	}
	ps = states/(1.0*ns);
	myOfile <<" msec. "<<  t <<" numberOfInputs :"<< ni <<" numberOfSequences: "<< ns << " numberOfSequencesPerState: "<< ps<< endl;

}
bool P::pref(string a, string b)
{
	if(a.size()>b.size())
		return false;
	for(int i = 0 ; i < a.size() ; i++)
	{
		if(a[i]!=b[i])
			return false;
	}
	return true;
}
//void P::genHSI()
//{
//
//}
void P::compactWset()
{
	vector<vector<string>> a;
	a.assign(states,vector<string>());
	for(int i = 0 ; i < pSet.size() ; i++)
	{
		if(pSet[i].sequence[0].size()>0)
		{
			tempW[pSet[i].pair.first].push_back(pSet[i].sequence[0]);
			tempW[pSet[i].pair.second].push_back(pSet[i].sequence[0]);
		}
	}
	for(int k = 0 ; k < tempW.size() ; k++)
	{
		for(int i = 0 ; i < tempW[k].size() ; i++)
		{
			for(int j = i+1 ; j < tempW[k].size() ; j++)
			{
				if(tempW[k][i]==tempW[k][j])
					tempW[k][j]="";
				if(pref(tempW[k][i],tempW[k][j]))
					tempW[k][i]="";
				if(pref(tempW[k][j],tempW[k][i]))
					tempW[k][j]="";
			}
		}
		for(int i = 0 ; i < tempW[k].size() ; i++)
		{
			if(tempW[k][i].size()>0)
			{
				a[k].push_back(tempW[k][i]);
			}
		}
	}
	tempW.clear();
	tempW.shrink_to_fit();
	tempW=a;
	/*vector<vector<string>> a;
	a.assign(states,vector<string>());
	for(int i = 0 ; i < pSet.size() ; i++)
	{
		if(pSet[i].sequence[0].size()>0)
		{
			tempW[pSet[i].pair.first].push_back(pSet[i].sequence[0]);
			tempW[pSet[i].pair.second].push_back(pSet[i].sequence[0]);
		}
	}
	for(int k = 0 ; k < tempW.size() ; k++)
	{
		for(int i = 0 ; i < tempW[k].size() ; i++)
		{
			for(int j = i+1 ; j < tempW[k].size() ; j++)
			{
				if(tempW[k][i]==tempW[k][j])
					tempW[k][j]="";
				if(pref(tempW[k][i],tempW[k][j]))
					tempW[k][i]="";
				if(pref(tempW[k][j],tempW[k][i]))
					tempW[k][j]="";
			}
		}
		for(int i = 0 ; i < tempW[k].size() ; i++)
		{
			if(tempW[k][i].size()>0)
			{
				a[k].push_back(tempW[k][i]);
			}
		}
	}
	tempW.clear();
	tempW.shrink_to_fit();
	tempW=a;*/
}
void P::Start(FSM &f)
{	

	for(int i = 0 ; i < pSet.size(); i++)
	{
		length = 1;
		currentInputSequence.assign(length,0);
		pairsBlock initialPair;
		initialPair.initial.first = pSet[i].pair.first;
		initialPair.initial.second = pSet[i].pair.second;
		initialPair.current = initialPair.initial;
		levelPairsBlocks l0;
		l0.l.push_back(initialPair);
		l0.inputSequence = "";
		allLevels.push_back(l0);

		vector<int> inputSequence = retreiveFirstInput();

		int splitted = 1;
		
		while(splitted !=0)
		{
			splitted = 1;
			string seq; 
			for(int j = 0 ; j < inputSequence.size() && splitted!=-2 && splitted!=0; j++)
			{
				splitted = applyInput(allLevels[j],inputSequence[j],f);
				if(splitted!=-2)
					seq.push_back(static_cast<char>(inputSequence[j]+97));
			}
			if(splitted!=0)
			{
				inputSequence =retrieveInputSequence();
				for(int h = 0 ; h < allLevels.size() ; h++)
				{
					allLevels[h].l.clear();
					allLevels[h].l.shrink_to_fit();
					allLevels[h].inputSequence.clear();
					allLevels[h].inputSequence.shrink_to_fit();
					allLevels.clear();
					allLevels.shrink_to_fit();
					pairsBlock initialPair;
					initialPair.initial.first = pSet[i].pair.first;
					initialPair.initial.second = pSet[i].pair.second;
					initialPair.current = initialPair.initial;
					levelPairsBlocks l0;
					l0.l.push_back(initialPair);
					l0.inputSequence = "";
					allLevels.push_back(l0);
				}
			}
			else if(splitted == 0)
			{
				pSet[i].sequence.push_back(seq);
				pSet[i].separated = true;
				for(int h = 0 ; h < allLevels.size() ; h++)
				{
					allLevels[h].l.clear();
					allLevels[h].l.shrink_to_fit();
					allLevels[h].inputSequence.clear();
					allLevels[h].inputSequence.shrink_to_fit();
					allLevels.clear();
					allLevels.shrink_to_fit();
				}
			}
		}
	}
}
vector<int> P::getInputSequence()
{
	return currentInputSequence;
}
vector<int> P::retreiveFirstInput()
{
	return this->currentInputSequence;
}
void P::increment(vector<int> &myArray)
{
	int firstIndex = 0 ;
	currentInputSequence[firstIndex]++;
	if(currentInputSequence[firstIndex] >= inputs)
	{
		rippleAdd(firstIndex,myArray);
	}
}
void P::rippleAdd(int index, vector<int> &myArray)
{
	if(myArray.size()>index)
	{
		myArray[index]=0;
	}
	if(myArray.size()>index+1)
	{
		int currentIndex = index+1;
		currentInputSequence[currentIndex]++;
		if(currentInputSequence[currentIndex] >= inputs)
		{
			rippleAdd(currentIndex,myArray);
		}
	}
	else{
		length++;
		currentInputSequence.assign(length,0);
	}
}
vector<int> P::retrieveInputSequence()
{
	int firstIndex = 0;
	if(currentInputSequence[firstIndex]+1 >= inputs)
	{
		increment(currentInputSequence);
	}
	else
	{
		currentInputSequence[firstIndex]++;
	}
	return currentInputSequence;
}
int P::applyInput(levelPairsBlocks & LPB, int input, FSM &f)
{
	int defined = 1;
	levelPairsBlocks temp;
	int separatedPairsCount = 0;
	for(int i = 0 ; i < LPB.l.size() ; i++)
	{
		if(LPB.l[i].current.first>= 0 && LPB.l[i].current.second>= 0)
		{
			levelPairsBlocks res = applyInputToAPair(LPB.l[i],input,f);
			if(res.l.size()>0)
			{
				for(int j = 0 ; j < res.l.size(); j++)
				{
					temp.l.push_back(res.l[j]);
				}
			}
			else
				defined = -2;
		}
	}
	if(defined==1){
		temp.inputSequence = LPB.inputSequence;
		temp.inputSequence.push_back(static_cast<char>(input+97));
		allLevels.push_back(temp);

		if(areAllSingletons(temp))
		{
			return 0;
		}
		return 1;
	}
	
	return -2;
}
levelPairsBlocks P::applyInputToAPair(pairsBlock & p, int input, FSM &f)
{
	levelPairsBlocks temp;
	vector<int> nsF = f.returnNextStateValue(p.current.first,input);
	vector<int> nsS = f.returnNextStateValue(p.current.second,input);
	//missing transitions ?
	int missing1 = 0;
	int missing2 = 0;
	bool merge = false;
	for(int i = 0 ; i < this->outputs ; i++)
	{
		if(nsF[i]<0)
			missing1++;
		if(nsS[i]<0)
			missing2++;
		if(nsF[i]==nsS[i] && (nsS[i]>=0  || nsF[i]>=0))
			merge = true;
	}
	if(merge || missing1>=this->outputs || missing2>=this->outputs)
		;
	else
	{
		for(int i = 0 ; i < this->outputs ; i++)
		{
			pairsBlock tempB;
			tempB.current.first = nsF[i];
			tempB.current.second = nsS[i];
			tempB.initial.first = p.initial.first;
			tempB.initial.second = p.initial.second;
			temp.l.push_back(tempB);
		}
	}
	return temp;
}
bool P::areAllSingletons(levelPairsBlocks & res)
{
	bool separated = true;
	for(int i = 0 ; i < res.l.size(); i++)
	{
		if(res.l[i].current.first >= 0 && res.l[i].current.second >= 0)
			separated = false;
	}
	return separated;
}