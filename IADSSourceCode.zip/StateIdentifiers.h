#include "ReadFSMs.h"


struct node
{
	vector<int> states;
	string path;
};

//IADS iads(f, 1, 0, 0);
//P petrenko(f,1,0,0);

class SI
{
public:
	SI(FSM &f);
	~SI();
	
	void Petrenko(FSM &f);
	void Uraz(FSM &f,int i,bool j, bool k);
	void printTestSuite(string,FSM&f,float t, bool,bool,bool);
	void END();
private:
	int states;
	int inputs; 
	int outputs;

	void sPaths(FSM &f);
	void buildTestSuite(vector<vector<string>> &u);
	void reach_to_states(FSM &f);
	bool pref(string a, string b);
	void compactTestSuite();
	
	vector<string> paths;
	vector<string> TS;
};

SI::SI(FSM &f)
{
	states = f.getStates();
	inputs = f.getInputs();
	outputs = f.getOutputs();
	for(int i =0 ; i < f.getStates() ; i++)
	{
		paths.push_back("");
	}

	sPaths(f);	
}
void SI::buildTestSuite(vector<vector<string>> &u)
{
	for(int i = 0 ; i < states && u.size()>0 ; i++)
	{
		for(int k = 0 ; k <u[i].size() ; k++)
		{
			string temp = paths[i];
			if(i!=0&&paths[i].size()==0)
				cout<<"Error"<<endl;
			temp.append(u[i][k]);
			TS.push_back(temp);
			char buf[6];
			for(int j = 0 ; j < inputs ; j++)
			{
				string temp2 = paths[i];
				string r;
				r.push_back(static_cast<char>(j+97));
				temp2.append(r);
				temp2.append(u[i][k]);
				TS.push_back(temp2);
			}
		}
	}
}
void SI::Uraz(FSM &f,int i, bool j, bool k)
{
	IADS myIADS(f,i,j,k);
	vector<vector<string>> u = myIADS.getSequences();//*/myIADS.printIADSs("SIGDA",f,0,false,false); //
	buildTestSuite(u);
	compactTestSuite();
	myIADS.~IADS();
}
void SI::printTestSuite(string fname, FSM &f, float time,bool a, bool b, bool alg)
{
	string ID = f.getID();
	ofstream myOfileSeqs;
	ofstream myOfileStats;
	string seqs;
	string stats;
	seqs=fname;
	seqs.append("_sequences_");
	seqs.append(".txt");
	stats=fname;
	stats.append("_stats_");
	stats.append(".txt");
	myOfileSeqs.open(seqs, ios::app);
	myOfileStats.open(stats, ios::app);
	int number_of_sequences = 0;
	int number_of_inputs = 0;
	float number_of_sequences_per_state = 0;
	if(alg)
	{
		myOfileSeqs <<"Uraz";
		myOfileStats <<"Uraz";
		if(a&&b){
			myOfileSeqs <<"-IS ";
			myOfileStats <<"-IS ";
		}
		else if(a&&!b){
			myOfileSeqs <<"-ISP ";
			myOfileStats <<"-ISP ";
		}
		else if(!a&&b){
			myOfileSeqs <<"-ISS ";
			myOfileStats <<"-ISS ";
		}
		else if(!a&&!b){
			myOfileSeqs <<"-NOIS ";
			myOfileStats <<"-NOIS ";
		}
	}
	else 
	{
		myOfileSeqs <<"Petrenko ";
		myOfileStats <<"Petrenko ";
	}

	//myOfileSeqs <<" ID:" << ID.c_str() << " nos:"<< states << " noi:"<< inputs << " noo: "<< outputs;
	myOfileSeqs <<ID.c_str() << " "<< states << " "<< inputs << " "<< outputs<<" ";
	myOfileStats<<ID.c_str() << " "<< states << " "<< inputs << " "<< outputs<<" "<< f.getCtr()<<" ";
	
	
	myOfileSeqs <<"TS: "<<" { ";
	for(int j = 0; j < TS.size() ; j++)
	{
		if(TS[j].size()>0)
		{
			number_of_sequences++;
			number_of_inputs+=TS[j].size();
			myOfileSeqs << TS[j] << " ";
		}
	}
	myOfileSeqs <<" }"<<endl;
	
	number_of_sequences_per_state = number_of_sequences/(1.0*states);
	//time tni tns ans
	myOfileStats << time <<" " << number_of_inputs<<" "<<number_of_sequences<< " "<< number_of_sequences_per_state<<  endl;
	myOfileStats.close();
	myOfileSeqs.close();
	TS.clear(); 
	TS.shrink_to_fit();
}
bool SI::pref(string a, string b)
{
	if(a.size()>b.size())
		return false;
	for(int i = 0 ; i < a.size() ; i++)
	{
		if(a[i]!=b[i])
			return false;
	}
	return true;
}
void SI::compactTestSuite()
{
	vector<string> tempW;
	for(int i = 0 ; i < TS.size() ; i++)
	{
		for(int j = i+1 ; j < TS.size() ; j++)
		{
			if(TS[i]==TS[j])
				TS[j]="";
			if(pref(TS[i],TS[j]))
				TS[i]="";
			if(pref(TS[j],TS[i]))
				TS[j]="";
		}
	}
	for(int i = 0 ; i < TS.size() ; i++)
	{
		if(TS[i].size()>0)
			tempW.push_back(TS[i]);
	}
	TS.clear();
	TS.shrink_to_fit();
	TS=tempW;
	tempW.clear();
}
void SI::Petrenko(FSM &f)
{
	P myP(f);
	vector<vector<string>> p = myP.getSequences();
	buildTestSuite(p);
	compactTestSuite();
	myP.~P();
}
void SI::sPaths(FSM &f)
{
	paths[0]="";
	reach_to_states(f);
	paths[0]="";
	int fg = 0 ;
}
void SI::reach_to_states(FSM &f)
{
	int source = 0;
	bool reached = false;

	vector<node> current;
	node temp;
	temp.states.push_back(source);
	current.push_back(temp);
	
	vector<node> next;
	//undefined inputs!
	//merging!
	vector<bool> dist;
	dist.push_back(true);
	while(dist.size()<states)
	{
		for(int i0 = 0 ; i0 < current.size() && dist.size()<states; i0++)
		{
			for(int j = 0 ; j < inputs && dist.size()<states ; j++)
			{
				vector<int> nextSet;
				for(int i = 0 ; i < current[i0].states.size(); i++)
				{
					vector<int> t = f.returnNextStateValue(current[i0].states[i],j);
					int ctr = 0;
					for(int ff = 0 ; ff<t.size(); ff++)
					{
						if(t[ff]<0)
							ctr++;
						else
							;
					}
					//if(ctr<inputs)
					if(ctr<outputs)
					{
						for(int ff = 0 ; ff<t.size(); ff++)
						{
							if(t[ff]<0)
								;
							else
							{
								bool added = false;
								for(int nxt = 0 ; nxt < nextSet.size(); nxt++)
								{
									if(t[ff]!=0&&nextSet[nxt]==t[ff])
										added = true;
								}
								
								if(!added)
									nextSet.push_back(t[ff]);
							}
							
						}
					}
					else 
						break;
				}
				if(nextSet.size()>0)
				{
					node temp2; 
					for(int k= 0 ; k < nextSet.size(); k++)
					{
						if(nextSet[k]<0)
							;
						else if(temp2.states.size()==0)
							temp2.states.push_back(nextSet[k]);
						else 
						{
							bool notAdded = true;
							for(int i1 = 0 ; i1<temp2.states.size() ; i1++)
							{
								if(temp2.states[i1]==nextSet[k])
									notAdded= false;
							}
							if(notAdded)
								temp2.states.push_back(nextSet[k]);							
						}
					}
					temp2.path.append(current[i0].path);
					temp2.path.push_back(static_cast<char>(j+97));
					next.push_back(temp2);
				}
			}
			//all inputs are applied
			for(int j = 0; j<next.size() ;j++)
			{
				if(next[j].states.size()==0)
					;
				else if(next[j].states.size()==1 && next[j].states[0]!=0)
				{
					if(paths[next[j].states[0]].size()==0)
					{
						paths[next[j].states[0]].append(next[j].path);
						dist.push_back(1);
					}
				}
				else if(next.size()>1)
				{
					;
				}
			}
		}
		current.clear();
		current.shrink_to_fit();
		current=next;
		next.clear();
		next.shrink_to_fit();
	}
}
void SI::END()
{
	TS.clear(); 
	TS.shrink_to_fit();
}
SI::~SI()
{
	paths.clear();
	paths.shrink_to_fit();
	TS.clear(); 
	TS.shrink_to_fit();
}